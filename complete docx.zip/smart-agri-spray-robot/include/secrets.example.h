#pragma once

// Copy this file to secrets.h and put in your real Wi-Fi details.
// secrets.h is listed in .gitignore and is never uploaded to GitHub.

#define WIFI_SSID "your-wifi-name"
#define WIFI_PASSWORD "your-wifi-password"
